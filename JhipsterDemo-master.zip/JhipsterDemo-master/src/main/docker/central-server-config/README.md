# Central configuration sources details
