import { IMember } from 'app/entities/member/member.model';

export interface IAddress {
  id?: string;
  houseNo?: number | null;
  street?: string | null;
  city?: string | null;
  state?: string | null;
  pincode?: number | null;
  member?: IMember | null;
}

export class Address implements IAddress {
  constructor(
    public id?: string,
    public houseNo?: number | null,
    public street?: string | null,
    public city?: string | null,
    public state?: string | null,
    public pincode?: number | null,
    public member?: IMember | null
  ) {}
}

export function getAddressIdentifier(address: IAddress): string | undefined {
  return address.id;
}
