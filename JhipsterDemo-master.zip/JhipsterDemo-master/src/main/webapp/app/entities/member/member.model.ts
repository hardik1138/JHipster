import { IBook } from 'app/entities/book/book.model';
import { IAddress } from 'app/entities/address/address.model';

export interface IMember {
  id?: string;
  name?: string | null;
  firstname?: string | null;
  lastname?: string | null;
  age?: number | null;
  books?: IBook[] | null;
  addresses?: IAddress[] | null;
}

export class Member implements IMember {
  constructor(
    public id?: string,
    public name?: string | null,
    public firstname?: string | null,
    public lastname?: string | null,
    public age?: number | null,
    public books?: IBook[] | null,
    public addresses?: IAddress[] | null
  ) {}
}

export function getMemberIdentifier(member: IMember): string | undefined {
  return member.id;
}
