import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { IMember, Member } from '../member.model';

import { MemberService } from './member.service';

describe('Member Service', () => {
  let service: MemberService;
  let httpMock: HttpTestingController;
  let elemDefault: IMember;
  let expectedResult: IMember | IMember[] | boolean | null;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    expectedResult = null;
    service = TestBed.inject(MemberService);
    httpMock = TestBed.inject(HttpTestingController);

    elemDefault = {
      id: 'AAAAAAA',
      name: 'AAAAAAA',
      firstname: 'AAAAAAA',
      lastname: 'AAAAAAA',
      age: 0,
    };
  });

  describe('Service methods', () => {
    it('should find an element', () => {
      const returnedFromService = Object.assign({}, elemDefault);

      service.find('ABC').subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'GET' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(elemDefault);
    });

    it('should create a Member', () => {
      const returnedFromService = Object.assign(
        {
          id: 'ID',
        },
        elemDefault
      );

      const expected = Object.assign({}, returnedFromService);

      service.create(new Member()).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'POST' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should update a Member', () => {
      const returnedFromService = Object.assign(
        {
          id: 'BBBBBB',
          name: 'BBBBBB',
          firstname: 'BBBBBB',
          lastname: 'BBBBBB',
          age: 1,
        },
        elemDefault
      );

      const expected = Object.assign({}, returnedFromService);

      service.update(expected).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'PUT' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should partial update a Member', () => {
      const patchObject = Object.assign(
        {
          lastname: 'BBBBBB',
        },
        new Member()
      );

      const returnedFromService = Object.assign(patchObject, elemDefault);

      const expected = Object.assign({}, returnedFromService);

      service.partialUpdate(patchObject).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'PATCH' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should return a list of Member', () => {
      const returnedFromService = Object.assign(
        {
          id: 'BBBBBB',
          name: 'BBBBBB',
          firstname: 'BBBBBB',
          lastname: 'BBBBBB',
          age: 1,
        },
        elemDefault
      );

      const expected = Object.assign({}, returnedFromService);

      service.query().subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'GET' });
      req.flush([returnedFromService]);
      httpMock.verify();
      expect(expectedResult).toContainEqual(expected);
    });

    it('should delete a Member', () => {
      service.delete('ABC').subscribe(resp => (expectedResult = resp.ok));

      const req = httpMock.expectOne({ method: 'DELETE' });
      req.flush({ status: 200 });
      expect(expectedResult);
    });

    describe('addMemberToCollectionIfMissing', () => {
      it('should add a Member to an empty array', () => {
        const member: IMember = { id: 'ABC' };
        expectedResult = service.addMemberToCollectionIfMissing([], member);
        expect(expectedResult).toHaveLength(1);
        expect(expectedResult).toContain(member);
      });

      it('should not add a Member to an array that contains it', () => {
        const member: IMember = { id: 'ABC' };
        const memberCollection: IMember[] = [
          {
            ...member,
          },
          { id: 'CBA' },
        ];
        expectedResult = service.addMemberToCollectionIfMissing(memberCollection, member);
        expect(expectedResult).toHaveLength(2);
      });

      it("should add a Member to an array that doesn't contain it", () => {
        const member: IMember = { id: 'ABC' };
        const memberCollection: IMember[] = [{ id: 'CBA' }];
        expectedResult = service.addMemberToCollectionIfMissing(memberCollection, member);
        expect(expectedResult).toHaveLength(2);
        expect(expectedResult).toContain(member);
      });

      it('should add only unique Member to an array', () => {
        const memberArray: IMember[] = [{ id: 'ABC' }, { id: 'CBA' }, { id: '9c82fa62-c3af-4f19-9bd8-db5f70332d37' }];
        const memberCollection: IMember[] = [{ id: 'ABC' }];
        expectedResult = service.addMemberToCollectionIfMissing(memberCollection, ...memberArray);
        expect(expectedResult).toHaveLength(3);
      });

      it('should accept varargs', () => {
        const member: IMember = { id: 'ABC' };
        const member2: IMember = { id: 'CBA' };
        expectedResult = service.addMemberToCollectionIfMissing([], member, member2);
        expect(expectedResult).toHaveLength(2);
        expect(expectedResult).toContain(member);
        expect(expectedResult).toContain(member2);
      });

      it('should accept null and undefined values', () => {
        const member: IMember = { id: 'ABC' };
        expectedResult = service.addMemberToCollectionIfMissing([], null, member, undefined);
        expect(expectedResult).toHaveLength(1);
        expect(expectedResult).toContain(member);
      });

      it('should return initial array if no Member is added', () => {
        const memberCollection: IMember[] = [{ id: 'ABC' }];
        expectedResult = service.addMemberToCollectionIfMissing(memberCollection, undefined, null);
        expect(expectedResult).toEqual(memberCollection);
      });
    });
  });

  afterEach(() => {
    httpMock.verify();
  });
});
