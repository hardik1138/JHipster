import { IMember } from 'app/entities/member/member.model';

export interface IBook {
  id?: string;
  name?: string | null;
  code?: string | null;
  author?: string | null;
  member?: IMember | null;
}

export class Book implements IBook {
  constructor(
    public id?: string,
    public name?: string | null,
    public code?: string | null,
    public author?: string | null,
    public member?: IMember | null
  ) {}
}

export function getBookIdentifier(book: IBook): string | undefined {
  return book.id;
}
