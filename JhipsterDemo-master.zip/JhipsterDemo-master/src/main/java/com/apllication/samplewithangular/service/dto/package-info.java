/**
 * Data Transfer Objects.
 */
package com.apllication.samplewithangular.service.dto;
