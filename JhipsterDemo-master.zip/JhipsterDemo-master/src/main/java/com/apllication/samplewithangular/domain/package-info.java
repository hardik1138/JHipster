/**
 * JPA domain objects.
 */
package com.apllication.samplewithangular.domain;
