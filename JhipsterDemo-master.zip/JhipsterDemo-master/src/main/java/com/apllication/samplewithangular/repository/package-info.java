/**
 * Spring Data JPA repositories.
 */
package com.apllication.samplewithangular.repository;
