package com.apllication.samplewithangular.service.mapper;

import com.apllication.samplewithangular.domain.Address;
import com.apllication.samplewithangular.domain.Member;
import com.apllication.samplewithangular.service.dto.AddressDTO;
import com.apllication.samplewithangular.service.dto.MemberDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Address} and its DTO {@link AddressDTO}.
 */
@Mapper(componentModel = "spring")
public interface AddressMapper extends EntityMapper<AddressDTO, Address> {
    @Mapping(target = "member", source = "member", qualifiedByName = "memberId")
    AddressDTO toDto(Address s);

    @Named("memberId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    MemberDTO toDtoMemberId(Member member);
}
