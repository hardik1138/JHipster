/**
 * Service layer beans.
 */
package com.apllication.samplewithangular.service;
