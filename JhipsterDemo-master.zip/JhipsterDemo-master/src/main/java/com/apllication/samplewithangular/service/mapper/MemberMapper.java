package com.apllication.samplewithangular.service.mapper;

import com.apllication.samplewithangular.domain.Member;
import com.apllication.samplewithangular.service.dto.MemberDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Member} and its DTO {@link MemberDTO}.
 */
@Mapper(componentModel = "spring")
public interface MemberMapper extends EntityMapper<MemberDTO, Member> {}
