/**
 * Spring Security configuration.
 */
package com.apllication.samplewithangular.security;
