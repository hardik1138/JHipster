/**
 * View Models used by Spring MVC REST controllers.
 */
package com.apllication.samplewithangular.web.rest.vm;
